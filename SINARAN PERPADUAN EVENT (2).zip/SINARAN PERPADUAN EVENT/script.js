// Function to show the selected section and hide others
function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');

    sections.forEach(section => {
        section.style.display = 'none'; // Hide all sections
    });

    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.style.display = 'block'; // Show the target section
    }
}


// Default: Display the first section on page load
document.addEventListener('DOMContentLoaded', () => {
    // Show the Dashboard section by default
    showSection('dashboard');

});


function editUser(id) {
    alert(`Edit user with ID ${id}`);
}

function deleteUser(id) {
    if (confirm('Are you sure you want to delete this user?')) {
        alert(`User with ID ${id} deleted.`);
    }
}
// Sample data for bookings (this should be dynamic in a real app)
const bookings = [
    { id: 1, studentName: "Nursyamimi Binti Muhamad Roslee", status: "Pending", bookingDate: "2024-12-10" },
    { id: 2, studentName: "Mohd Ali Bin Ahmad", status: "Pending", bookingDate: "2024-12-12"},
    { id: 3, studentName: "Anis Athirah Binti Amir", status: "Pending", bookingDate: "2024-12-10" },
    { id: 4, studentName: "Mohd Aiman Bin Zulkifli", status: "Accepted", bookingDate: "2024-12-12"},
    { id: 5, studentName: "Zulaikha Binti Abdul", status: "Pending", bookingDate: "2024-12-10" }
];

// Function to open the modal and populate the data based on bookingId
function openEditModal(bookingId) {
    // Find the booking data for the given bookingId
    const booking = bookings.find(b => b.id === bookingId);

    if (booking) {
        // Populate the modal fields with booking data
        document.getElementById('studentName').value = booking.studentName;
        document.getElementById('status').value = booking.status;
        document.getElementById('bookingDate').value = booking.bookingDate;

        // Show the modal using Bootstrap Modal API
        const modal = new bootstrap.Modal(document.getElementById('editBookingModal'));
        modal.show();
    } else {
        console.error("Booking not found for ID:", bookingId);
    }
}

// Example function to save the booking status (add your own logic here)
function updateBookingStatus() {
    const studentName = document.getElementById('studentName').value;
    const status = document.getElementById('status').value;
    const bookingDate = document.getElementById('bookingDate').value;

    // In a real app, you would send the updated data to the server (e.g., with AJAX)
    alert(`Updated booking for ${studentName}: Status - ${status}, Date - ${bookingDate}`);

    // Hide the modal
    const modal = new bootstrap.Modal(document.getElementById('editBookingModal'));
    modal.hide();
}
// Select all update buttons
const updateButtons = document.querySelectorAll('.update-btn');

let bookingIdToDelete = null;  // Store the ID of the booking to delete

// Function to open the modal when Delete button is clicked
function deleteBooking(bookingId) {
    bookingIdToDelete = bookingId;  // Store the booking ID to delete
    document.getElementById('confirmDeleteModal').style.display = 'block';  // Show the modal
}

// Function to close the modal
function closeModal() {
    document.getElementById('confirmDeleteModal').style.display = 'none';  // Hide the modal
}

// When the "Yes, Delete" button is clicked
document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
    if (bookingIdToDelete !== null) {
        // Proceed with the delete action (e.g., AJAX or other logic)
        alert(`Booking ${bookingIdToDelete} has been deleted!`);

        // Close the modal after the action
        closeModal();
        
        // Optional: Remove the row from the table or update the UI dynamically
        // Example: document.querySelector(`#bookingRow-${bookingIdToDelete}`).remove();
    }
});
  

// Function to update event details
function updateEvent() {
    const eventDate = document.getElementById("eventDate").value;
    const eventFee = document.getElementById("eventFee").value;
    const eventContact = document.getElementById("eventContact").value;
    
    // Get the uploaded files for pictures (you can implement logic to upload these images)
    const picture1 = document.getElementById("eventPicture1").files[0];
    const picture2 = document.getElementById("eventPicture2").files[0];
    const picture3 = document.getElementById("eventPicture3").files[0];
    const picture4 = document.getElementById("eventPicture4").files[0];
    const picture5 = document.getElementById("eventPicture5").files[0];
    
    // Get the destination names
    const destination1 = document.getElementById("destination1").value;
    const destination2 = document.getElementById("destination2").value;
    const destination3 = document.getElementById("destination3").value;
    const destination4 = document.getElementById("destination4").value;
    const destination5 = document.getElementById("destination5").value;
    
    // You can send the updated data to the backend (using AJAX or a form submission)
    alert(`Event updated with Date: ${eventDate}, Fee: ${eventFee}, Contact: ${eventContact}`);
}

// Function to delete event
function deleteEvent() {
    const confirmDelete = confirm("Are you sure you want to delete this event? This action cannot be undone.");
    if (confirmDelete) {
        alert("Event has been deleted!");
        // You can implement the backend logic to delete the event here
    } else {
        alert("The event was not deleted.");
    }
}

// Function to update destination details
function updateDestination() {
    const destinationName = document.getElementById("destinationName").value;
    const destinationDescription = document.getElementById("destinationDescription").value;
    const destinationLocation = document.getElementById("destinationLocation").value;
    const estimatedTime = document.getElementById("estimatedTime").value;
    
    // Get the uploaded images for destination
    const mainPicture = document.getElementById("mainPicture").files[0];
    const picture2 = document.getElementById("picture2").files[0];
    const picture3 = document.getElementById("picture3").files[0];

    // Send the updated data to the backend (using AJAX or other methods)
    alert(`Destination updated: ${destinationName}, Location: ${destinationLocation}`);
}

// Function to delete destination
function deleteDestination() {
    const confirmDelete = confirm("Are you sure you want to delete this destination? This action cannot be undone.");
    if (confirmDelete) {
        alert("Destination has been deleted!");
        // You can implement the backend logic to delete the destination here
    } else {
        alert("The destination was not deleted.");
    }
}


// Sample data for the graphs and stats
const studentData = {
    member: 4,
    nonMember: 3
};

const sponsorData = {
    monetary: 2,
    nonMonetary: 3,
    totalAmount: 5000  // In USD
};

const totalDestinations = 5;

// Set the values dynamically for the stats
document.getElementById('totalSponsors').textContent = sponsorData.monetary + sponsorData.nonMonetary;
document.getElementById('totalSponsorshipAmount').textContent = `$${sponsorData.totalAmount}`;
document.getElementById('totalDestinations').textContent = totalDestinations;

// Student Registration Graph
const studentChart = new Chart(document.getElementById('studentChart').getContext('2d'), {
    type: 'bar',
    data: {
        labels: ['Member', 'Non-Member'],
        datasets: [{
            label: 'Student Registration',
            data: [studentData.member, studentData.nonMember],
            backgroundColor: ['#007bff', '#f39c12'],
            borderColor: ['#0056b3', '#e67e22'],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

document.addEventListener("DOMContentLoaded", function () {
    // Sample data for the dashboard
    const studentData = {
        member: 4,
        nonMember: 3
    };

    const sponsorData = {
        monetary: 2,
        nonMonetary: 3,
        totalAmount: 5000  // Total monetary sponsorship amount in USD
    };

    const totalDestinations = 5;

    // Update the HTML content dynamically with JavaScript
    document.getElementById("studentsCount").textContent = studentData.member;
    document.getElementById("nonMembersCount").textContent = studentData.nonMember;
    document.getElementById("monetarySponsors").textContent = sponsorData.monetary;
    document.getElementById("nonMonetarySponsors").textContent = sponsorData.nonMonetary;
    document.getElementById("totalDestinations").textContent = totalDestinations;
    document.getElementById("totalAmount").textContent = `$${sponsorData.totalAmount}`;

    // Student Registration Graph (Bar Chart)
    const studentChart = new Chart(document.getElementById('studentChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: ['Member', 'Non-Member'],
            datasets: [{
                label: 'Student Registration',
                data: [studentData.member, studentData.nonMember],
                backgroundColor: ['#007bff', '#f39c12'],
                borderColor: ['#0056b3', '#e67e22'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Sponsor Graph (Pie Chart)
    const sponsorChart = new Chart(document.getElementById('sponsorChart').getContext('2d'), {
        type: 'pie',
        data: {
            labels: ['Monetary Sponsors', 'Non-Monetary Sponsors'],
            datasets: [{
                label: 'Sponsors',
                data: [sponsorData.monetary, sponsorData.nonMonetary],
                backgroundColor: ['#28a745', '#dc3545'],
                borderColor: ['#218838', '#c82333'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
            }
        }
    });
});

// Check if the user is logged in
// window.onload = function() {
//     const loggedIn = localStorage.getItem("loggedIn");

//     if (!loggedIn) {
//         // If not logged in, redirect to the login page
//         window.location.href = "login.html"; // The Login Page
//     }
// }; 

function logout() {
    // Remove the login status from localStorage
    localStorage.removeItem("loggedIn");

    // Redirect to the login page
    window.location.href = "login.html";  // Replace with your login page URL
}