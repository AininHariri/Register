// Function to handle the active link and display content
function showContent(contentId, clickedLink) {
    // Hide all content sections
    const contentSections = document.querySelectorAll(".content");
    contentSections.forEach(section => section.style.display = "none");
  
    // Show the selected content section
    const selectedContent = document.getElementById(contentId);
    if (selectedContent) {
      selectedContent.style.display = "block";
    }
  
    // Remove active class from all links
    const allLinks = document.querySelectorAll("nav ul li a");
    allLinks.forEach(link => link.classList.remove("active"));
  
    // Add active class to the clicked link
    clickedLink.classList.add("active");
  }
  
  // Optionally, set the default active link on page load
  document.addEventListener("DOMContentLoaded", function() {
    // Set the default active link to Dashboard
    const dashboardLink = document.getElementById("dashboardLink");
    dashboardLink.classList.add("active");
    showContent('dashboardContent', dashboardLink);
  });

  // CONTENT AREA FOR NEW FORM
  // JavaScript to handle form logic and dynamic content
document.getElementById("category").addEventListener("change", updateForm);
document.getElementById("itemToSponsor").addEventListener("input", updateForm);
document.getElementById("agreement").addEventListener("change", updateForm);

function hideAllContent() {
  const contents = document.querySelectorAll('.content');
  contents.forEach(content => content.style.display = 'none');
}

function removeActiveClass() {
  const links = document.querySelectorAll('nav ul li a');
  links.forEach(link => link.classList.remove('active'));
}

// Show fields based on selected category
function updateForm() {
  const selectedCategory = document.getElementById("category").value;
  const sponsorBudgetField = document.getElementById("budget");
  const itemField = document.getElementById("item");
  const quantityField = document.getElementById("quantity");

  sponsorBudgetField.style.display = "none";
  itemField.style.display = "none";
  quantityField.style.display = "none";

  if (selectedCategory === "Monetary") {
    sponsorBudgetField.style.display = "block";
  } else if (selectedCategory === "Non-monetary") {
    itemField.style.display = "block";
  }

  // Show quantity field if an item is selected
  if (document.getElementById("itemToSponsor").value) {
    quantityField.style.display = "block";
  }

  // Show the mutual agreement section when selected
  const agreementValue = document.getElementById("agreement").value;
  if (agreementValue) {
    document.getElementById("formOutput").style.display = "block";
  } else {
    document.getElementById("formOutput").style.display = "none";
  }
}

// Function to switch between content sections (Dashboard, New Form, etc.)
function showContent(contentId, linkElement) {
  hideAllContent();
  removeActiveClass();
  const contentToShow = document.getElementById(contentId);
  contentToShow.style.display = "block";
  linkElement.classList.add("active");
}

// Handle form submission and display entered data
document.getElementById("submitBtn").addEventListener("click", function(event) {
  event.preventDefault();

  // Collect form data
  const contactName = document.getElementById("contactName").value;
  const email = document.getElementById("email").value;
  const logo = document.getElementById("logo").files[0];
  const sponsorName = document.getElementById("sponsorName").value;
  const contactNumber = document.getElementById("contactNumber").value;
  const address = document.getElementById("address").value;
  const category = document.getElementById("category").value;
  const sponsorBudget = document.getElementById("sponsorBudget") ? document.getElementById("sponsorBudget").value : '';
  const itemToSponsor = document.getElementById("itemToSponsor") ? document.getElementById("itemToSponsor").value : '';
  const itemQuantity = document.getElementById("itemQuantity") ? document.getElementById("itemQuantity").value : '';
  const agreement = document.getElementById("agreement").value;

  // Generate the form data output
  const formData = `
    Contact Name: ${contactName}
    Email: ${email}
    Sponsor Logo: ${logo ? logo.name : 'No logo uploaded'}
    Sponsor Name: ${sponsorName}
    Contact Number: ${contactNumber}
    Address: ${address}
    Category: ${category}
    ${category === 'Monetary' ? `Sponsor Budget: ${sponsorBudget}` : ''}
    ${category === 'Non-monetary' ? `Item to Sponsor: ${itemToSponsor}, Quantity: ${itemQuantity}` : ''}
    Agreement: ${agreement}
  `;

  // Display the generated form data
  document.getElementById("generatedData").textContent = formData;
  document.getElementById("formOutput").style.display = "block";  // Show output section
});

// Initial setup
hideAllContent();
document.getElementById("dashboardLink").classList.add("active");
document.getElementById("dashboardContent").style.display = "block";

// CONTENT AREA FOR DETAILS
// Function to handle sidebar link clicks
function handleLinkClick(event, contentId) {
    event.preventDefault(); // Prevent default anchor behavior
  
    // Hide all content sections
    const allContent = document.querySelectorAll(".content");
    allContent.forEach(content => content.style.display = "none");
  
    // Show the content section for the clicked link
    const selectedContent = document.getElementById(contentId);
    if (selectedContent) {
      selectedContent.style.display = "block";
    }
  
    // Remove 'active' class from all links
    const allLinks = document.querySelectorAll("nav ul li a");
    allLinks.forEach(link => link.classList.remove("active"));
  
    // Add 'active' class to the clicked link
    event.target.classList.add("active");
  }
  
  // Add event listeners to sidebar links
  document.querySelectorAll("nav ul li a").forEach(link => {
    link.addEventListener("click", function (event) {
      // Pass the clicked link's target and associated content ID
      const contentId = link.id.replace("Link", "Content"); // Map link ID to content ID
      handleLinkClick(event, contentId);
    });
  });

  // CONTENT AREA FOR PROGRESS
  // Function to show/hide content based on the selected menu
function showContent(contentId, clickedLink) {
    // Hide all content sections
    var contents = document.querySelectorAll('.content');
    contents.forEach(function(content) {
      content.style.display = 'none';
    });
  
    // Show the selected content
    var selectedContent = document.getElementById(contentId);
    if (selectedContent) {
      selectedContent.style.display = 'flex'; // Display the selected content
    }
  
    // Remove active class from all links
    var links = document.querySelectorAll('nav ul li a');
    links.forEach(function(link) {
      link.classList.remove('active');
    });
  
    // Add active class to the clicked link
    clickedLink.classList.add('active');
  }
  
  // Initially show the dashboard or any other default content
  document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("dashboardLink").classList.add("active");
    showContent('progress', document.getElementById("progressLink"));
  });



  // CONTENT AREA FOR CONTACT US
  // Function to show/hide content based on the selected menu
function showContent(contentId) {
  // Hide all content sections
  var contents = document.querySelectorAll('.content');
  contents.forEach(function(content) {
    content.style.display = 'none';
  });

  // Show the selected content
  var selectedContent = document.getElementById(contentId);
  if (selectedContent) {
    selectedContent.style.display = 'flex'; // Display the selected content
  }

  // Remove 'active' class from all links
  var links = document.querySelectorAll('nav ul li a');
  links.forEach(function(link) {
    link.classList.remove('active');
  });

  // Add 'active' class to the clicked link
  var selectedLink = document.getElementById(contentId + 'Link');
  if (selectedLink) {
    selectedLink.classList.add('active');
  }
}

// Initially highlight the default page (if any)
showContent('contact');  // Change 'contact' to whichever is your default content

  
  